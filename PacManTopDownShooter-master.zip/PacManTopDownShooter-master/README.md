# Pac-Man: The Top Down Shooter
Small single player/multiplayer java game, built using Slick2D and inspired by Pac-Man. Multiplayer (co-op only) is quite laggy and no solution has been implemented for players with different screen sizes.
